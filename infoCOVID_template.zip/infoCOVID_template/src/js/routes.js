
import HomePage from '../pages/home.svelte';

var routes = [
  {
    path: '/',
    component: HomePage,
  },
];

export default routes;
